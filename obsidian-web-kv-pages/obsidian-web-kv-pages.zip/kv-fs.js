/* obsidian-web (KV edition) — vault storage on Cloudflare Workers KV.
 *
 * Presents the vault as a FileSystemDirectoryHandle-compatible object, so the existing shims
 * (app-shim.js / mobile-shim.js) can use it exactly like a real folder.
 *
 *   - The whole file index lives in memory (one KV list at open, then refreshed every few minutes).
 *   - File contents are fetched lazily and cached in IndexedDB (re-downloaded only when the mtime/size changed).
 *   - WRITES ARE BATCHED: changes stay local (and are saved in IndexedDB at once, so a closed tab loses nothing),
 *     and are sent to KV when you have been idle for a while. Repeated saves of one file become a single KV write.
 *
 * Loaded before shim.js / launcher.js, so it can keep the browser's original fetch (the shims rewrite
 * root-absolute fetch URLs into /app/).
 */
(() => {
  'use strict';
  if (window.__owKV) return;
  const nativeFetch = window.fetch.bind(window);

  const siteRoot = (() => {
    try {
      const u = new URL(document.currentScript.src);
      u.search = ''; u.hash = ''; u.pathname = u.pathname.replace(/(?:app\/)?kv-fs\.js$/, '');
      return u;
    } catch (_) { return new URL('./', location.href); }
  })();
  const API = new URL('api/', siteRoot);
  const LOGIN = new URL('login.html', siteRoot);

  const MAX_FILE = 25 * 1024 * 1024;     // Workers KV value limit
  const REFRESH_MS = 10 * 60 * 1000;     // re-list KV (picks up changes from other devices); KV free plan allows 1,000 list ops/day
  const IDLE_STOP_MS = 30 * 60 * 1000;   // no automatic refresh while nobody touches the page
  const SNAP_FRESH_MS = 60 * 1000;       // reuse the last list when a page opens right after another
  const graceMs = () => num('ow.kv.grace', 90) * 1000; // KV list is eventually consistent: for this long, trust our own writes over it
  const MEM_CAP = 80 * 1024 * 1024;      // in-memory content cache (clean entries only are evicted)
  const num = (k, d) => { try { const v = Number(localStorage.getItem(k)); return v > 0 ? v : d; } catch (_) { return d; } };

  // ---------------------------------------------------------------- small helpers
  const dom = (name, msg) => new DOMException(msg || name, name);
  const split = p => { const i = p.lastIndexOf('/'); return i < 0 ? ['', p] : [p.slice(0, i), p.slice(i + 1)]; };
  const join = (d, n) => (d ? d + '/' + n : n);
  const utf8len = s => new TextEncoder().encode(s).length;
  const keyOk = p => utf8len(p) <= 500;
  function sameBytes(a, b) { if (a.length !== b.length) return false; for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false; return true; }
  async function toBytes(d) {
    if (typeof d === 'string') return new TextEncoder().encode(d);
    if (d instanceof ArrayBuffer) return new Uint8Array(d);
    if (ArrayBuffer.isView(d)) return new Uint8Array(d.buffer, d.byteOffset, d.byteLength);
    if (d && typeof d.arrayBuffer === 'function') return new Uint8Array(await d.arrayBuffer()); // Blob / File / our lazy file
    return new TextEncoder().encode(String(d));
  }

  // ---------------------------------------------------------------- IndexedDB: pending changes, content cache, index snapshot
  let dbP = null;
  const db = () => dbP || (dbP = new Promise((res, rej) => {
    const r = indexedDB.open('obsidian-web-kv', 1);
    r.onupgradeneeded = () => { const d = r.result; d.createObjectStore('pending'); d.createObjectStore('cache'); d.createObjectStore('meta'); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  }));
  const idb = (store, mode, fn) => db().then(d => new Promise((res, rej) => {
    const t = d.transaction(store, mode), out = fn(t.objectStore(store));
    t.oncomplete = () => res(out && typeof out === 'object' && 'result' in out ? out.result : undefined);
    t.onerror = t.onabort = () => rej(t.error);
  })).catch(() => undefined); // IndexedDB trouble (private mode ...) must never break the vault
  const idbGet = (s, k) => idb(s, 'readonly', st => st.get(k));
  const idbPut = (s, k, v) => idb(s, 'readwrite', st => st.put(v, k));
  const idbDel = (s, k) => idb(s, 'readwrite', st => st.delete(k));
  const idbEntries = s => db().then(d => new Promise((res, rej) => {
    const t = d.transaction(s), st = t.objectStore(s), ks = st.getAllKeys(), vs = st.getAll();
    t.oncomplete = () => res(ks.result.map((k, i) => [k, vs.result[i]])); t.onerror = () => rej(t.error);
  })).catch(() => []);

  // ---------------------------------------------------------------- state
  const nodes = new Map();     // path -> {k:'f'|'d', size, mtime}      what the app sees now
  const kids = new Map();      // dir path -> Map(name -> 'f'|'d')       ('' = vault root)
  const remote = new Map();    // path -> {k, size, mtime}               last known state of KV
  const dirty = new Set();     // paths whose local state is not in KV yet
  const ver = new Map();       // path -> change counter (to detect edits made while a flush was running)
  const data = new Map();      // path -> Uint8Array                     content in memory
  const flushedAt = new Map(); // path -> time of our last KV write/delete
  const inflight = new Map();
  let memBytes = 0, lastRefresh = 0, flushing = null, again = false, timer = null, firstDirtyAt = 0;
  let status = 'ok', statusNote = '', fails = 0, ui = false, redirecting = false;

  function link(p, k) { const [d, n] = split(p); let m = kids.get(d); if (!m) kids.set(d, m = new Map()); m.set(n, k); }
  function unlink(p) { const [d, n] = split(p); const m = kids.get(d); if (m) m.delete(n); }
  function ensureParents(p) {
    let [d] = split(p); const chain = [];
    while (d) {
      const n = nodes.get(d);
      if (n) { if (n.k === 'f') throw dom('TypeMismatchError'); break; }
      chain.push(d); [d] = split(d);
    }
    for (const c of chain.reverse()) { nodes.set(c, { k: 'd', size: 0, mtime: 0 }); link(c, 'd'); if (!kids.has(c)) kids.set(c, new Map()); }
  }
  function remember(p, bytes) {
    const old = data.get(p); if (old) memBytes -= old.length;
    data.set(p, bytes); memBytes += bytes.length;
    if (memBytes > MEM_CAP) for (const [k, v] of data) { // evict oldest clean entries
      if (memBytes <= MEM_CAP * 0.75) break;
      if (!dirty.has(k)) { data.delete(k); memBytes -= v.length; }
    }
  }
  function forget(p) { const old = data.get(p); if (old) { memBytes -= old.length; data.delete(p); } }

  // ---------------------------------------------------------------- write budget (Workers KV free plan: 1,000 writes/day, UTC)
  const dayKey = () => 'ow.kv.w.' + new Date().toISOString().slice(0, 10);
  const writesToday = () => { try { return Number(localStorage.getItem(dayKey())) || 0; } catch (_) { return 0; } };
  function addWrites(n) {
    try {
      const k = dayKey();
      localStorage.setItem(k, String(writesToday() + n));
      for (let i = localStorage.length - 1; i >= 0; i--) { const x = localStorage.key(i); if (x && x.startsWith('ow.kv.w.') && x !== k) localStorage.removeItem(x); }
    } catch (_) { /* ignore */ }
  }
  const timing = () => {
    const w = writesToday();
    if (w >= 400) return { idle: 300000, max: 900000 };                                  // getting close: send less often
    return { idle: num('ow.kv.idle', 45) * 1000, max: num('ow.kv.max', 180) * 1000 };
  };
  const paused = () => writesToday() >= num('ow.kv.limit', 900);

  // ---------------------------------------------------------------- network
  function goLogin() {
    if (redirecting) return; redirecting = true;
    location.href = LOGIN.href + '?next=' + encodeURIComponent(location.pathname + location.search);
  }
  async function call(method, route, params, body, headers, keepalive) {
    const u = new URL(route, API);
    if (params) for (const [k, v] of Object.entries(params)) u.searchParams.set(k, v);
    const init = { method, credentials: 'same-origin', cache: 'no-store', headers: { 'X-OW': '1', ...(headers || {}) } };
    if (body !== undefined) init.body = body;
    if (keepalive && (!body || body.byteLength < 60000)) init.keepalive = true;
    let r;
    try { r = await nativeFetch(u, init); } catch (e) { const err = new Error('network'); err.net = true; throw err; }
    if (r.status === 401) { goLogin(); const err = new Error('auth'); err.auth = true; throw err; }
    return r;
  }

  // ---------------------------------------------------------------- local mutations
  function touch(p) { ver.set(p, (ver.get(p) || 0) + 1); dirty.add(p); persist(p); schedule(); }
  function persist(p) {
    const n = nodes.get(p);
    if (!n) idbPut('pending', p, { op: 'del' });
    else if (n.k === 'd') idbPut('pending', p, { op: 'dir', mtime: n.mtime });
    else idbPut('pending', p, { op: 'put', mtime: n.mtime, data: data.get(p) || new Uint8Array(0) });
  }
  function settle(p) { // a path that never reached KV and is gone again needs no write at all
    if (remote.has(p)) touch(p); else { dirty.delete(p); ver.delete(p); idbDel('pending', p); schedule(); }
  }
  function removeNode(p) {
    const n = nodes.get(p); if (!n) return;
    if (n.k === 'd') { for (const name of [...(kids.get(p) || new Map()).keys()]) removeNode(join(p, name)); kids.delete(p); }
    nodes.delete(p); unlink(p); forget(p);
    settle(p);
  }
  function dropLocal(p) { // removal that came from KV (another device): no write back
    const n = nodes.get(p); if (!n) return;
    if (n.k === 'd' && kids.get(p) && kids.get(p).size) return;
    nodes.delete(p); unlink(p); forget(p); kids.delete(p);
  }
  function mkdirNode(p) {
    if (!keyOk(p)) throw dom('NotAllowedError', 'name too long');
    ensureParentsMustExist(p);
    nodes.set(p, { k: 'd', size: 0, mtime: Date.now() }); link(p, 'd'); if (!kids.has(p)) kids.set(p, new Map());
    touch(p);
  }
  function ensureParentsMustExist(p) {
    const [d] = split(p);
    if (!d) return;
    const n = nodes.get(d);
    if (!n) throw dom('NotFoundError'); if (n.k !== 'd') throw dom('TypeMismatchError');
  }
  function commitFile(p, bytes) {
    if (bytes.length > MAX_FILE) throw dom('QuotaExceededError', 'file is larger than 25 MiB (Workers KV limit)');
    if (!keyOk(p)) throw dom('NotAllowedError', 'name too long');
    ensureParentsMustExist(p);
    const cur = nodes.get(p); if (cur && cur.k === 'd') throw dom('TypeMismatchError');
    nodes.set(p, { k: 'f', size: bytes.length, mtime: Date.now() });
    dirty.add(p);                      // before remember(): unsent data must never be evicted from memory
    remember(p, bytes); link(p, 'f');
    touch(p);
  }

  // ---------------------------------------------------------------- reading file content
  function readData(p) {
    const hit = data.get(p); if (hit) return Promise.resolve(hit);
    if (inflight.has(p)) return inflight.get(p);
    const n = nodes.get(p); if (!n || n.k !== 'f') return Promise.reject(dom('NotFoundError'));
    if (n.size === 0) { const e = new Uint8Array(0); remember(p, e); return Promise.resolve(e); }
    const pr = (async () => {
      const c = await idbGet('cache', p);
      if (c && c.m === n.mtime && c.size === n.size) { remember(p, c.data); return c.data; }
      let r;
      try { r = await call('GET', 'file', { p }); } catch (e) { if (e.auth) throw dom('NotAllowedError'); throw dom('NetworkError'); }
      if (r.status === 404) throw dom('NotFoundError');
      if (!r.ok) throw dom('NetworkError', 'HTTP ' + r.status);
      const bytes = new Uint8Array(await r.arrayBuffer());
      const m = Number(r.headers.get('X-OW-M') || 0), cur = nodes.get(p);
      // KV caches reads at the edge for a short while: keep the bytes only if they are the version we expect
      if (cur && cur.mtime === m && !dirty.has(p)) { remember(p, bytes); idbPut('cache', p, { m, size: bytes.length, data: bytes }); }
      return bytes;
    })().finally(() => inflight.delete(p));
    inflight.set(p, pr);
    return pr;
  }

  // ---------------------------------------------------------------- handles (FileSystemDirectoryHandle / FileSystemFileHandle look-alikes)
  class KVBlob { // what getFile() returns: size and mtime are known, the bytes are fetched only when asked for
    constructor(p, n) { this.name = split(p)[1]; this.size = n.size; this.lastModified = n.mtime; this.type = ''; this._p = p; }
    async arrayBuffer() { const b = await readData(this._p); return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); }
    async text() { return new TextDecoder().decode(await readData(this._p)); }
    async bytes() { return new Uint8Array(await this.arrayBuffer()); }
    stream() { const p = this._p; return new ReadableStream({ async pull(c) { c.enqueue(await readData(p)); c.close(); } }); }
    slice() { throw new Error('slice() is not supported on KV files; use arrayBuffer()'); }
  }
  class KVWritable {
    constructor(p, init) { this._p = p; this._buf = init; this._len = init.length; this._pos = 0; this._done = false; }
    _room(n) { if (n > this._buf.length) { const nb = new Uint8Array(Math.max(n, this._buf.length * 2, 64)); nb.set(this._buf.subarray(0, this._len)); this._buf = nb; } }
    async write(d) {
      if (this._done) throw dom('InvalidStateError');
      const isCmd = d && typeof d === 'object' && !(d instanceof Blob) && !(d instanceof ArrayBuffer) && !ArrayBuffer.isView(d) && (d.type === 'write' || d.type === 'seek' || d.type === 'truncate');
      if (isCmd) {
        if (d.type === 'seek') return this.seek(d.position);
        if (d.type === 'truncate') return this.truncate(d.size);
        if (d.position != null) this._pos = d.position;
        d = d.data;
      }
      const b = await toBytes(d), end = this._pos + b.length;
      if (end > MAX_FILE) throw dom('QuotaExceededError', 'file is larger than 25 MiB (Workers KV limit)');
      this._room(end);
      if (this._pos > this._len) this._buf.fill(0, this._len, this._pos);
      this._buf.set(b, this._pos); this._pos = end; if (end > this._len) this._len = end;
    }
    async seek(n) { this._pos = n; }
    async truncate(n) { this._room(n); if (n > this._len) this._buf.fill(0, this._len, n); this._len = n; if (this._pos > n) this._pos = n; }
    async close() {
      if (this._done) return; this._done = true;
      commitFile(this._p, this._buf.slice(0, this._len));
    }
    async abort() { this._done = true; }
  }
  class KVFileHandle {
    constructor(p) { this.kind = 'file'; this._p = p; this.name = split(p)[1]; }
    async getFile() { const n = nodes.get(this._p); if (!n) throw dom('NotFoundError'); if (n.k !== 'f') throw dom('TypeMismatchError'); return new KVBlob(this._p, n); }
    async createWritable(o) {
      const n = nodes.get(this._p); if (!n) throw dom('NotFoundError'); if (n.k !== 'f') throw dom('TypeMismatchError');
      const init = o && o.keepExistingData ? (await readData(this._p)).slice() : new Uint8Array(0);
      return new KVWritable(this._p, init);
    }
    async isSameEntry(o) { return !!o && o._p === this._p && o.kind === 'file'; }
    async queryPermission() { return 'granted'; }
    async requestPermission() { return 'granted'; }
  }
  class KVDirHandle {
    constructor(p) { this.kind = 'directory'; this._p = p; this.name = split(p)[1]; }
    _child(name) { if (!name || name === '.' || name === '..' || name.includes('/')) throw new TypeError('invalid name'); return join(this._p, name); }
    async getDirectoryHandle(name, o) {
      const cp = this._child(name), n = nodes.get(cp);
      if (n) { if (n.k === 'd') return new KVDirHandle(cp); throw dom('TypeMismatchError'); }
      if (!(o && o.create)) throw dom('NotFoundError');
      mkdirNode(cp); return new KVDirHandle(cp);
    }
    async getFileHandle(name, o) {
      const cp = this._child(name), n = nodes.get(cp);
      if (n) { if (n.k === 'f') return new KVFileHandle(cp); throw dom('TypeMismatchError'); }
      if (!(o && o.create)) throw dom('NotFoundError');
      commitFile(cp, new Uint8Array(0)); return new KVFileHandle(cp);
    }
    async removeEntry(name, o) {
      const cp = this._child(name), n = nodes.get(cp);
      if (!n) throw dom('NotFoundError');
      if (n.k === 'd' && (kids.get(cp) || new Map()).size && !(o && o.recursive)) throw dom('InvalidModificationError');
      removeNode(cp);
    }
    async *entries() {
      for (const [name, k] of [...(kids.get(this._p) || new Map())]) yield [name, k === 'd' ? new KVDirHandle(join(this._p, name)) : new KVFileHandle(join(this._p, name))];
    }
    async *keys() { for await (const [n] of this.entries()) yield n; }
    async *values() { for await (const [, h] of this.entries()) yield h; }
    [Symbol.asyncIterator]() { return this.entries(); }
    async isSameEntry(o) { return !!o && o._p === this._p && o.kind === 'directory'; }
    async queryPermission() { return 'granted'; }
    async requestPermission() { return 'granted'; }
  }

  // ---------------------------------------------------------------- syncing with KV
  async function fetchIndex() {
    const out = []; let cursor = null;
    do {
      const r = await call('GET', 'list', cursor ? { cursor } : null);
      if (!r.ok) throw new Error('list failed: HTTP ' + r.status);
      const j = await r.json(); out.push(...j.entries); cursor = j.cursor;
    } while (cursor);
    return out;
  }
  const recent = (p, now) => (flushedAt.get(p) || 0) > now - graceMs();
  // KV's list can lag behind our own writes for a while. Right after we wrote/deleted a path, a list entry that is
  // missing, or older than what we wrote, is a stale view; a NEWER one means another device changed it, so accept it.
  function staleView(p, r, now) {
    if (!recent(p, now)) return false;
    const mine = remote.get(p);
    return !mine || r.mtime < mine.mtime;
  }
  function applyList(entries) {
    const incoming = new Map();
    for (const [k, p, size, mtime] of entries) incoming.set(p, { k: k === 'd' ? 'd' : 'f', size, mtime });
    const now = Date.now();
    for (const [p] of [...remote]) {
      if (incoming.has(p) || recent(p, now)) continue;
      remote.delete(p);
      if (!dirty.has(p)) dropLocal(p);                       // deleted from another device
    }
    for (const [p, r] of incoming) {
      if (staleView(p, r, now)) continue;
      remote.set(p, r);
      if (dirty.has(p)) continue;                            // our unsent change wins
      const n = nodes.get(p);
      if (r.k === 'd') { if (!n) { try { ensureParents(p); } catch (_) { continue; } nodes.set(p, { k: 'd', size: 0, mtime: 0 }); link(p, 'd'); if (!kids.has(p)) kids.set(p, new Map()); } continue; }
      if (n && n.k === 'f' && n.size === r.size && n.mtime === r.mtime) continue;
      if (n && n.k === 'd') continue;
      try { ensureParents(p); } catch (_) { continue; }
      nodes.set(p, { k: 'f', size: r.size, mtime: r.mtime }); link(p, 'f'); forget(p);   // changed on another device
    }
  }
  const saveSnapshot = ts => idbPut('meta', 'index', { ts, entries: [...remote].map(([p, r]) => [r.k, p, r.size, r.mtime]) });
  async function refresh() {
    if (flushing) return;
    const list = await fetchIndex();
    applyList(list); lastRefresh = Date.now(); saveSnapshot(lastRefresh);
    if (status === 'offline') setStatus('ok');
    updateBadge();
  }
  async function loadPending() {
    for (const [p, rec] of await idbEntries('pending')) {
      try {
        if (rec.op === 'put') { ensureParents(p); nodes.set(p, { k: 'f', size: rec.data.length, mtime: rec.mtime }); link(p, 'f'); remember(p, rec.data); }
        else if (rec.op === 'dir') { ensureParents(p); nodes.set(p, { k: 'd', size: 0, mtime: rec.mtime || 0 }); link(p, 'd'); if (!kids.has(p)) kids.set(p, new Map()); }
        else if (rec.op === 'del') { const n = nodes.get(p); if (n) { nodes.delete(p); unlink(p); forget(p); if (n.k === 'd') kids.delete(p); } }
        dirty.add(p); ver.set(p, 1);
      } catch (_) { idbDel('pending', p); }
    }
  }

  // ---------------------------------------------------------------- batched flush
  function schedule() {
    updateBadge();
    if (!dirty.size) { firstDirtyAt = 0; clearTimeout(timer); return; }
    if (flushing) return;                                    // flush() reschedules itself when it is done
    const now = Date.now(); if (!firstDirtyAt) firstDirtyAt = now;
    const { idle, max } = timing();
    const due = Math.min(now + idle, firstDirtyAt + max);
    clearTimeout(timer); timer = setTimeout(() => flush(false), Math.max(500, due - now));
  }
  async function pool(items, size, fn) {
    let i = 0; const results = [];
    await Promise.all(Array.from({ length: Math.min(size, items.length) }, async () => {
      while (i < items.length) { const it = items[i++]; results.push(await fn(it)); }
    }));
    return results;
  }
  function flush(force, unloading) {
    if (flushing) { again = true; return flushing; }
    clearTimeout(timer); timer = null;
    if (!dirty.size) { updateBadge(); return Promise.resolve(); }
    if (!force && paused()) { setStatus('paused'); return Promise.resolve(); }
    flushing = (async () => {
      setStatus('syncing');
      let failed = false;
      try {
        const ops = [];
        for (const p of [...dirty]) {
          const v = ver.get(p) || 0, n = nodes.get(p), r = remote.get(p);
          if (n && n.k === 'f') {
            const bytes = data.get(p) || await readData(p).catch(() => null);
            if (!bytes) continue;
            if (r && r.k === 'f' && r.size === bytes.length) { // unchanged content (e.g. a re-save): no write needed
              const c = await idbGet('cache', p);
              if (c && c.m === r.mtime && c.size === r.size && sameBytes(c.data, bytes)) { n.mtime = r.mtime; ops.push({ p, v, type: 'noop' }); continue; }
            }
            ops.push({ p, v, type: 'put', bytes, m: n.mtime });
          } else if (n && n.k === 'd') {
            const empty = !(kids.get(p) && kids.get(p).size);
            ops.push({ p, v, type: empty && !(r && r.k === 'd') ? 'dirput' : 'noop', m: n.mtime });
          } else ops.push({ p, v, type: r ? (r.k === 'd' ? 'dirdel' : 'del') : 'noop' });
        }
        await pool(ops, 4, async op => {
          const { p, v } = op;
          try {
            if (op.type === 'put') {
              const r = await call('PUT', 'file', { p }, op.bytes, { 'X-OW-M': String(op.m) }, unloading);
              if (r.status === 413) { notify('25MiBを超えるため保存できません: ' + p); remote.delete(p); }
              else if (!r.ok) throw new Error('HTTP ' + r.status);
              else { remote.set(p, { k: 'f', size: op.bytes.length, mtime: op.m }); idbPut('cache', p, { m: op.m, size: op.bytes.length, data: op.bytes }); addWrites(1); flushedAt.set(p, Date.now()); }
            } else if (op.type === 'del' || op.type === 'dirdel') {
              const r = await call('DELETE', op.type === 'del' ? 'file' : 'dir', { p }, undefined, undefined, unloading);
              if (!r.ok) throw new Error('HTTP ' + r.status);
              remote.delete(p); addWrites(1); flushedAt.set(p, Date.now());
            } else if (op.type === 'dirput') {
              const r = await call('PUT', 'dir', { p }, undefined, { 'X-OW-M': String(op.m) }, unloading);
              if (!r.ok) throw new Error('HTTP ' + r.status);
              remote.set(p, { k: 'd', size: 0, mtime: op.m }); addWrites(1); flushedAt.set(p, Date.now());
            }
            if ((ver.get(p) || 0) === v) { dirty.delete(p); ver.delete(p); idbDel('pending', p); }
          } catch (e) { if (e.auth) throw e; failed = true; if (e.net) setStatus('offline'); }
        });
        saveSnapshot(lastRefresh);
      } catch (e) { failed = true; if (!e.auth) console.error('[obsidian-web kv] flush failed', e); }
      flushing = null; firstDirtyAt = 0;
      if (failed) { fails++; if (status !== 'offline') setStatus('error'); setTimeout(() => schedule(), Math.min(60000 * fails, 600000)); }
      else { fails = 0; setStatus('ok'); }
      if (again) { again = false; if (dirty.size && !failed) flush(false); } else if (dirty.size && !failed) schedule();
      updateBadge();
    })();
    return flushing;
  }

  // ---------------------------------------------------------------- status badge (shown inside the Obsidian page)
  let badge = null, noteTimer = null;
  function setStatus(s) { status = s; updateBadge(); }
  function notify(text) { statusNote = text; updateBadge(); clearTimeout(noteTimer); noteTimer = setTimeout(() => { statusNote = ''; updateBadge(); }, 10000); }
  function updateBadge() {
    if (!badge) return;
    const n = dirty.size;
    let t, c = '#2e7d32';
    if (status === 'syncing') { t = '☁ 同期中…'; c = '#1565c0'; }
    else if (status === 'offline') { t = '☁ オフライン' + (n ? '(未保存 ' + n + ')' : ''); c = '#757575'; }
    else if (status === 'error') { t = '☁ 同期エラー(未保存 ' + n + ')'; c = '#c62828'; }
    else if (status === 'paused') { t = '☁ 書込上限が近いため保留中(未保存 ' + n + ')'; c = '#ef6c00'; }
    else if (n) { t = '☁ 未保存 ' + n; c = '#f9a825'; }
    else t = '☁ 同期済み';
    if (statusNote) t += ' / ' + statusNote;
    badge.textContent = t; badge.style.background = c;
    badge.title = '本日この端末からのKV書き込み: ' + writesToday() + ' 回(無料枠は全端末で1日1,000回、UTC)\nクリックで今すぐ同期';
  }
  function mountBadge() {
    const add = () => {
      if (badge || !document.body) return;
      badge = document.createElement('div');
      badge.style.cssText = 'position:fixed;left:6px;bottom:6px;z-index:2147483000;font:11px/1.4 system-ui,sans-serif;color:#fff;padding:2px 8px;border-radius:10px;opacity:.55;cursor:pointer;user-select:none;max-width:70vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis';
      badge.addEventListener('mouseenter', () => { badge.style.opacity = '1'; }); badge.addEventListener('mouseleave', () => { badge.style.opacity = '.55'; });
      badge.addEventListener('click', async () => { try { await flush(true); await refresh(); } catch (_) { /* shown in badge */ } });
      document.body.appendChild(badge); updateBadge();
    };
    if (document.body) add(); else document.addEventListener('DOMContentLoaded', add);
  }

  // ---------------------------------------------------------------- open
  let openP = null, handlersSet = false;
  function open(opts) {
    ui = !!(opts && opts.ui);
    if (!openP) openP = (async () => {
      const snap = await idbGet('meta', 'index');
      if (snap && Date.now() - snap.ts < SNAP_FRESH_MS) { applyList(snap.entries); lastRefresh = snap.ts; }
      else {
        try { const list = await fetchIndex(); applyList(list); lastRefresh = Date.now(); saveSnapshot(lastRefresh); }
        catch (e) {
          if (e.auth) throw new Error('auth');
          if (!snap) throw new Error('offline'); // never opened on this device and no connection
          applyList(snap.entries); lastRefresh = snap.ts; status = 'offline';
        }
      }
      await loadPending();
      if (!handlersSet) {
        handlersSet = true;
        const out = () => { if (dirty.size) flush(false, true); };
        document.addEventListener('visibilitychange', () => {
          if (document.hidden) out();
          else if (ui && Date.now() - lastRefresh > SNAP_FRESH_MS) refresh().catch(() => {});
        });
        window.addEventListener('pagehide', out);
        window.addEventListener('online', () => { if (status === 'offline') { setStatus('ok'); schedule(); } });
        let lastActive = Date.now();
        for (const ev of ['keydown', 'pointerdown', 'touchstart', 'wheel']) window.addEventListener(ev, () => { lastActive = Date.now(); }, { passive: true, capture: true });
        if (ui) setInterval(() => { if (!document.hidden && Date.now() - lastActive < IDLE_STOP_MS && Date.now() - lastRefresh > REFRESH_MS) refresh().catch(() => { if (!navigator.onLine) setStatus('offline'); }); }, 30000);
      }
      if (ui) mountBadge();
      schedule();
      return new KVDirHandle('');
    })();
    return openP;
  }

  window.__owKV = { open, flush: () => flush(true), refresh, writesToday, isEmpty: () => !(kids.get('') && kids.get('').size) };
})();
