/* obsidian-web (KV edition) — Cloudflare Pages "advanced mode" worker.
 *
 *   Pages > Settings > Variables and Secrets : PASSWORD   (Secret, required)
 *                                              SESSION_SECRET (Secret, optional: signs login cookies)
 *   Pages > Settings > Bindings              : KV namespace  ->  variable name  VAULT_KV
 *
 * Every request needs a valid login cookie, except the login page and POST /api/login.
 * The vault lives in KV:   "f:<path>"  file content (metadata {s:size, m:mtime})
 *                          "d:<path>"  marker for an (empty) folder
 */
const COOKIE = 'ow_auth';
const SESSION_DAYS = 30;
const MAX_VALUE = 25 * 1024 * 1024; // Workers KV value limit
const enc = new TextEncoder();

const NO_STORE = { 'Cache-Control': 'no-store' };
const json = (status, obj, extra) => new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json', ...NO_STORE, ...(extra || {}) } });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const toHex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
const fromHex = h => { const o = new Uint8Array(h.length >> 1); for (let i = 0; i < o.length; i++) o[i] = parseInt(h.substr(i * 2, 2), 16); return o; };

async function sessionKey(env) {
  const raw = await crypto.subtle.digest('SHA-256', enc.encode('ow-session-v1|' + (env.SESSION_SECRET || '') + '|' + env.PASSWORD));
  return crypto.subtle.importKey('raw', raw, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
}
async function makeToken(env) {
  const exp = Math.floor(Date.now() / 1000) + SESSION_DAYS * 86400;
  const sig = await crypto.subtle.sign('HMAC', await sessionKey(env), enc.encode('ow1.' + exp));
  return exp + '.' + toHex(sig);
}
async function isAuthed(request, env) {
  const m = new RegExp('(?:^|;\\s*)' + COOKIE + '=([^;]+)').exec(request.headers.get('Cookie') || '');
  if (!m) return false;
  const [exp, sig] = m[1].split('.');
  if (!exp || !sig || !/^\d+$/.test(exp) || !/^[0-9a-f]{64}$/.test(sig)) return false;
  if (Number(exp) < Date.now() / 1000) return false;
  try { return await crypto.subtle.verify('HMAC', await sessionKey(env), fromHex(sig), enc.encode('ow1.' + exp)); } catch (_) { return false; }
}
async function passwordOk(env, given) {
  const a = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(String(given == null ? '' : given))));
  const b = new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(env.PASSWORD)));
  let d = 0; for (let i = 0; i < 32; i++) d |= a[i] ^ b[i];
  return d === 0;
}
const cookieHeader = (value, maxAge) => COOKIE + '=' + value + '; Path=/; Max-Age=' + maxAge + '; HttpOnly; Secure; SameSite=Strict';

// vault path -> validated string, or null
function vpath(url) {
  const p = url.searchParams.get('p');
  if (!p || p.length > 500 || p.startsWith('/') || p.endsWith('/') || /[\u0000-\u001f]/.test(p)) return null;
  if (p.split('/').some(s => s === '' || s === '.' || s === '..')) return null;
  if (enc.encode(p).length > 500) return null; // KV key limit is 512 bytes, minus the "f:" prefix
  return p;
}

async function api(request, env, url) {
  const kv = env.VAULT_KV;
  if (!kv) return json(500, { error: 'KV binding VAULT_KV is not configured' });
  const route = url.pathname.slice('/api/'.length);
  const method = request.method;
  if (method !== 'GET') {
    if (request.headers.get('X-OW') !== '1') return json(403, { error: 'missing header' });
    const origin = request.headers.get('Origin');
    if (origin && origin !== url.origin) return json(403, { error: 'bad origin' });
  }

  if (route === 'ping') return json(200, { ok: true, t: Date.now() });

  if (route === 'list' && method === 'GET') {
    const r = await kv.list({ limit: 1000, cursor: url.searchParams.get('cursor') || undefined });
    const entries = r.keys.map(k => { const md = k.metadata || {}; return [k.name[0], k.name.slice(2), md.s || 0, md.m || 0]; });
    return json(200, { entries, cursor: r.list_complete ? null : r.cursor });
  }

  const p = vpath(url);
  if (p === null) return json(400, { error: 'bad path' });

  if (route === 'file') {
    const key = 'f:' + p;
    if (method === 'GET') {
      const { value, metadata } = await kv.getWithMetadata(key, { type: 'arrayBuffer', cacheTtl: 30 });
      if (value === null) return json(404, { error: 'not found' });
      const md = metadata || {};
      // an empty file is stored as one placeholder byte (empty KV values are avoided)
      return new Response(md.s === 0 ? new ArrayBuffer(0) : value, { status: 200, headers: { 'Content-Type': 'application/octet-stream', 'X-OW-M': String(md.m || 0), ...NO_STORE } });
    }
    if (method === 'PUT') {
      if (Number(request.headers.get('Content-Length') || 0) > MAX_VALUE) return json(413, { error: 'too large' });
      const body = await request.arrayBuffer();
      if (body.byteLength > MAX_VALUE) return json(413, { error: 'too large' });
      const m = Number(request.headers.get('X-OW-M')) || Date.now();
      await kv.put(key, body.byteLength ? body : new Uint8Array(1), { metadata: { s: body.byteLength, m } });
      return json(200, { ok: true });
    }
    if (method === 'DELETE') { await kv.delete(key); return json(200, { ok: true }); }
  }
  if (route === 'dir') {
    const key = 'd:' + p;
    if (method === 'PUT') { await kv.put(key, '1', { metadata: { s: 0, m: Number(request.headers.get('X-OW-M')) || Date.now() } }); return json(200, { ok: true }); }
    if (method === 'DELETE') { await kv.delete(key); return json(200, { ok: true }); }
  }
  return json(404, { error: 'unknown route' });
}

async function login(request, env, url) {
  if (request.headers.get('X-OW') !== '1') return json(403, { error: 'missing header' });
  const origin = request.headers.get('Origin');
  if (origin && origin !== url.origin) return json(403, { error: 'bad origin' });
  let body = {};
  try { body = await request.json(); } catch (_) { /* empty */ }
  if (!(await passwordOk(env, body.password))) { await sleep(1000); return json(401, { error: 'bad password' }); }
  return json(200, { ok: true }, { 'Set-Cookie': cookieHeader(await makeToken(env), SESSION_DAYS * 86400) });
}

const isLoginPage = p => p === '/login' || p === '/login.html';

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const p = url.pathname;
    try {
      if (!env.PASSWORD) return new Response('PASSWORD (secret) is not set. Pages > Settings > Variables and Secrets', { status: 503, headers: NO_STORE });

      if (p === '/api/login' && request.method === 'POST') return await login(request, env, url);
      if (p === '/api/logout' && request.method === 'POST') return json(200, { ok: true }, { 'Set-Cookie': cookieHeader('', 0) });

      const authed = await isAuthed(request, env);
      if (p.startsWith('/api/')) return authed ? await api(request, env, url) : json(401, { error: 'auth' });

      if (!authed && !isLoginPage(p)) {
        const nav = request.headers.get('Sec-Fetch-Mode') === 'navigate' || (request.headers.get('Accept') || '').includes('text/html');
        if (nav && request.method === 'GET') return new Response(null, { status: 302, headers: { Location: '/login.html?next=' + encodeURIComponent(p + url.search), ...NO_STORE } });
        return new Response('unauthorized', { status: 401, headers: NO_STORE });
      }

      const res = await env.ASSETS.fetch(request);
      const out = new Response(res.body, res);
      out.headers.set('X-Content-Type-Options', 'nosniff');
      out.headers.set('Referrer-Policy', 'no-referrer');
      out.headers.set('X-Robots-Tag', 'noindex, nofollow');
      if (!authed) out.headers.set('Cache-Control', 'no-store');
      return out;
    } catch (e) {
      return json(500, { error: String((e && e.message) || e) });
    }
  },
};
